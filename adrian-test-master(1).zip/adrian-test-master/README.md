# adrian-test
Primera entrega para trabajo en Workana


Consignas Test

Desarrollo Full-Stack

A partir del boceto, construye en código PHP un index que utilice el archivo db.json para
construir un HTML basado en los bocetos planteados en la carpeta MATERIAL.

HTML ➔ Usar etiquetas de forma semántica. ➔ Usar clases legibles para otros programadores,
podes usar metodologías como https://en.bem.info/methodology/

SASS ➔ Usar un pre​procesador (ej: Sass) y post​procesador (ej: Autoprefixer). ➔ Minificar el
CSS (en el proceso de build, con Gulp, Grunt o Prepros). ➔ Escribir el CSS en varios archivos,
pero usar en el HTML un solo CSS generado.

Material ➔ Para el material iconográfico utilizar ​http://fontawesome.io/icons/​. ➔ No debe
contener ninguna imagen.
